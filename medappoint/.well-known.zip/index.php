<?php
header("Location: public");
?>