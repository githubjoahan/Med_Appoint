<div class="table-responsive">
    <table class="table align-items-center table-flush">
        <thead class="thead-light">
            <tr>
                <th scope="col">Especialidad</th>
                <th scope="col">Fecha</th>
                <th scope="col">Hora</th>
                <th scope="col">Estado</th>
                <th scope="col">Opciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $oldAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row">
                    <?php echo e($appointment->specialty->name); ?>

                    </td>
                <td>
                    <?php echo e($appointment->scheduled_date); ?>

                </td>
                <td>
                    <?php echo e($appointment->scheduled_time_12); ?>

                </td>
                <td>
                    <?php echo e($appointment->status); ?>

                </td>
                <td>
                    <a href="<?php echo e(url('/appointments/'.$appointment->id)); ?>" class="btn btn-primary btn-sm">
                        Ver
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="card-body">
    <?php echo e($oldAppointments->links()); ?>

</div>