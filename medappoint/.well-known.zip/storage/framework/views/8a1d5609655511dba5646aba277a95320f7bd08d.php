

<?php $__env->startSection('content'); ?>
<div class="card shadow">
  <div class="card-header border-0">
    <div class="row align-items-center">
      <div class="col">
        <h3 class="mb-0">Registrar Nueva Cita</h3>
      </div>
      <div class="col text-right">
        <a href="<?php echo e(url('patients')); ?>" class="btn btn-sm btn-default">Cancelar y volver</a>
      </div>
    </div>
  </div>
  <div class="card-body">
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form action="<?php echo e(url('appointments')); ?>" method="POST">
        <?php echo csrf_field(); ?>
         <div class="form-group">
             <label for="description">Descripcion</label>
             <input name="description" value="<?php echo e(old('description')); ?>" id="description" type="text" class="form-control" 
             placeholder="Describe brevemente la consulta" required>
         </div>
        
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="specialty">Especialidad</label>
              <select  id="specialty" name="specialty_id"  class="form-control" required>
                <option value="">Seleccionar especialidad</option>
                <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($specialty->id); ?>" <?php if(old('specialty_id') == $specialty->id): ?> selected <?php endif; ?>><?php echo e($specialty->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group col-md-6">
              <label for="doctor">Médico</label>
              <select name="doctor_id" id="doctor" class="form-control" required>
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($doctor->id); ?>" <?php if(old('doctor_id') == $doctor->id): ?> selected <?php endif; ?>><?php echo e($doctor->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>

              <div class="form-group" >
                  <label for="dni">Fecha</label>
                      <div class="input-group input-group-alternative">
                          <div class="input-group-prepend">
                              <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                          </div>
                          <input class="form-control datepicker" placeholder="Seleccionar Fecha" 
                                  id="date" name="scheduled_date"  type="text" 
                                  value="<?php echo e(old('scheduled_date', date('Y-m-d'))); ?>" 
                                  data-date-format="yyyy-mm-dd"
                                  data-date-start-date="<?php echo e(date('Y-m-d')); ?>" 
                                  data-date-end-date="+30d">
                      </div>
              </div>
              <div class="form-group">
                <label for="address">Hora de atención</label>
                <div id="hours">
                  <?php if($intervals): ?>
                    <?php $__currentLoopData = $intervals['morning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $interval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="custom-control custom-radio mb-3">
                        <input name="scheduled_time" value="<?php echo e($interval['start']); ?>" class="custom-control-input" id="intervalMorning<?php echo e($key); ?>" type="radio" required>
                        <label class="custom-control-label" for="intervalMorning<?php echo e($key); ?>"><?php echo e($interval['start']); ?> - <?php echo e($interval['end']); ?></label>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $intervals['afternoon']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $interval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="custom-control custom-radio mb-3">
                        <input name="scheduled_time" value="<?php echo e($interval['start']); ?>" class="custom-control-input" id="intervalAfternoon<?php echo e($key); ?>" type="radio" required>
                        <label class="custom-control-label" for="intervalAfternoon<?php echo e($key); ?>"><?php echo e($interval['start']); ?> - <?php echo e($interval['end']); ?></label>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <div class="alert alert-info" role="alert">
                      Seleccione un médico y una fecha, para ver sus horas disponibles.
                    </div>
                  <?php endif; ?>
                </div>
              </div>

              <div class="form-group">
                <label for="type">Tipo de consulta</label>
                <div class="custom-control custom-radio mb-3">
                  <input name="type" class="custom-control-input" id="type1" type="radio"
                    <?php if(old('type', 'Consulta') == 'Consulta'): ?> checked <?php endif; ?> value="Consulta">
                  <label class="custom-control-label" for="type1">Consulta</label>
                </div>
                <div class="custom-control custom-radio mb-3">
                  <input name="type" class="custom-control-input" id="type2" type="radio"
                    <?php if(old('type') == 'Examen'): ?> checked <?php endif; ?> value="Examen">
                  <label class="custom-control-label" for="type2">Examen</label>
                </div>
                <div class="custom-control custom-radio mb-3">
                  <input name="type" class="custom-control-input" id="type3" type="radio"
                    <?php if(old('type') == 'Operación'): ?> checked <?php endif; ?> value="Operación">
                  <label class="custom-control-label" for="type3">Operación</label>
                </div>
              </div>
              
              <button type="submit" class="btn btn-primary">
                Guardar
              </button>
      </form>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<script>
  let $doctor, $date, $specialty, $hours;
  let iRadio;
  const noHoursAlert = `<div class="alert alert-danger" role="alert">
    <strong>Lo sentimos!</strong> No se encontraron horas disponibles para el médico en el día seleccionado.
    </div>`;



  $(function () {
    $specialty =$('#specialty');
    $doctor = $('#doctor');
    $date =$('#date');
    $hours =$('#hours');

  $specialty.change(() => {
    const specialtyId = $specialty.val();
    const url = `../specialties/${specialtyId}/doctors`;  //`/specialties/{specialty}/doctors`;
    $.getJSON(url, onDoctorsLoaded);
     
    });
    $doctor.change(loadHours);
    $date.change(loadHours);
    // Agrega el código para ocultar el calendario después de seleccionar una fecha
    $date.datepicker({
        // ... Opciones de configuración del calendario ...
    }).on('changeDate', function () {
        $(this).datepicker('hide');
    });
});
   
    function onDoctorsLoaded(doctors) {
    let htmlOptions = '';
    doctors.forEach(doctor => {
      htmlOptions += `<option value="${doctor.id}">${doctor.name}</option>`;
    });
    $doctor.html(htmlOptions);
    loadHours(); // side-effect
     
  } 

  function loadHours() {
	const selectedDate = $date.val();
	const doctorId = $doctor.val();
	const url = `../schedule/hours?date=${selectedDate}&doctor_id=${doctorId}`;
    $.getJSON(url, displayHours);
}

function displayHours(data) {
	if (!data.morning && !data.afternoon || 
		data.morning.length===0 && data.afternoon.length===0) {

		$hours.html(noHoursAlert);
		return;
	}

	let htmlHours = '';
	iRadio = 0;

	if (data.morning) {
		const morning_intervals = data.morning;
		morning_intervals.forEach(interval => {
			htmlHours += getRadioIntervalHtml(interval);
		});
	}
	if (data.afternoon) {
		const afternoon_intervals = data.afternoon;
		afternoon_intervals.forEach(interval => {
			htmlHours += getRadioIntervalHtml(interval);
		});
	}
	$hours.html(htmlHours);
}

function getRadioIntervalHtml(interval) {
	const text = `${interval.start} - ${interval.end}`;

	return `<div class="custom-control custom-radio mb-3">
  <input name="scheduled_time" value="${interval.start}" class="custom-control-input" id="interval${iRadio}" type="radio" required>
  <label class="custom-control-label" for="interval${iRadio++}">${text}</label>
  </div>`;
}


</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>