<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center bg-primary text-white" style="background: none; border: none;">
                    <h4><?php echo e(__('Recuperar contraseña')); ?></h4>
                </div>

                <div class="card-body custom-card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="email" class="col-form-label"><?php echo e(__('Para restablecer la contraseña, introduce la dirección de correo electrónico que utilizaste para iniciar sesión en el portal.')); ?></label>
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Correo electrónico">
                            <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <a href="https://myappointment.com.mx/public/login" class="btn btn-outline-secondary btn-block">Cancelar</a>
                            </div>
                            <div class="col-md-6 mt-2 mt-md-0">
                                <button type="submit" class="btn btn-outline-primary btn-block"><?php echo e(__('Recuperar')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>