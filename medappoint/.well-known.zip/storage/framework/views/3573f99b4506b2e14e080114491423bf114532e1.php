

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/css/bootstrap-select.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card shadow">
    <div class="card-header border-0">
        <div class="row align-items-center">
            <div class="col">
                <h3 class="mb-0">Editar Medico</h3>
            </div>
            <div class="col text-right">
                <a href="<?php echo e(url('doctors')); ?>" class="btn btn-sm btn-default">Cancelar y volver</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <form action="<?php echo e(url('doctors/'.$doctor->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name"> Nombre del medico</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $doctor->name)); ?>" required>
            </div>
            <div class="form-group">
                <label for="email"> E-mail</label>
                <input type="text" name="email" class="form-control" value="<?php echo e(old('email',$doctor->email)); ?>">
            </div>
            <div class="form-group">
                <label for="dni"> DNI</label>
                <input type="text" name="dni" class="form-control" value="<?php echo e(old('dni',$doctor->dni)); ?>">
            </div>
            <div class="form-group">
                <label for="address"> Direccion</label>
                <input type="text" name="address" class="form-control" value="<?php echo e(old('address', $doctor->address)); ?>">
            </div>
            <div class="form-group">
                <label for="phone"> Telefono</label>
                <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone',$doctor->phone)); ?>">
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="text" name="password" class="form-control" value="">
                <p>Ingrese un valor solo si desea modificar la contraseña</p>
            </div>

            <div class="form-group">
                <label for="specialties">Especialidades</label>
                <select name="specialties[]" id="specialties" class="form-control
                         selectpicker" data-style="btn-default" multiple title="Seleccione una o varias">
                    <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($specialty->id); ?>"><?php echo e($specialty->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

            <button type="submit" class="btn btn-primary">
                Guardar
            </button>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>
<script>
$(document).ready(() => {
    $('#specialties').selectpicker('val', <?php echo json_encode($specialty_ids, 15, 512) ?>);
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>